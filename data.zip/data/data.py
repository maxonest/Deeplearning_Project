import json
from tqdm import tqdm
from langchain_unstructured import UnstructuredLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from openai import OpenAI

# ===================== 【配置区】 =====================
# DeepSeek 密钥 & 接口配置
DEEPSEEK_API_KEY = "sk-d03d0fbcdae946f298a454e536d0f59f"
DEEPSEEK_BASE_URL = "https://api.deepseek.com"  # 固定官方地址，不要改

INPUT_FILE = "小红书文本.txt"
OUTPUT_FILE = "dataset_xhs.json"
SOURCE_NAME = "小红书运动健康相关科普"
# =============================================================

# 提示词  会根据处理文本的不同进行适当修改
QA_PAIRS_SYSTEM_PROMPT = """
你是运动健康领域的专业专家，请根据用户提供的文本，生成专业、易懂的问答对。
要求：
1. 问题要贴近用户日常提问，口语化、不生硬；
2. 答案要基于文本内容，准确、完整，保留关键信息，不得补充外部知识，不得推测；
3. 优先生成运动健康类内容，比如训练方法类、动作技巧类、注意事项类、原理分析类、康复建议类、营养知识类，不要阅读量点赞量类、粉丝运营类、情绪感悟类内容；
4. 生成问答对的数量要适当，对于每段长文字最多生成5个问答对，每段短文字生成一个即可；
5. 严格只返回 JSON 数组，不要多余解释、不要Markdown格式。
格式示例：
[
    {"question": "新手健身一周练几次合适？", "answer": "新手建议每周3次力量训练，每次30-45分钟，给肌肉留出恢复时间。"},
    {"question": "运动前需要热身吗？", "answer": "是的，建议做5-10分钟动态热身，降低受伤风险。"}
]
"""

QA_PAIRS_HUMAN_PROMPT = """
文本内容：
{text}

请生成问答对：
"""

def split_document(filepath):
    """切分文本，适配Markdown格式文本"""
    loader = UnstructuredLoader(filepath)
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1500,
        chunk_overlap=100,
        separators=["## ", "\n\n", "\n", " "]  # 适配你的## Markdown标题
    )
    return loader.load_and_split(splitter)

def create_client():
    """创建 DeepSeek 客户端"""
    client = OpenAI(
        api_key=DEEPSEEK_API_KEY,
        base_url=DEEPSEEK_BASE_URL
    )
    return client

def main():
    # 1. 初始化
    print("开始生成数据集...")
    documents = split_document(INPUT_FILE)
    client = create_client()
    all_data = []

    # 2. 遍历文本块生成问答
    for doc in tqdm(documents, desc="生成中"):
        text = doc.page_content.strip()
        if len(text) < 50:
            continue

        # 拼接完整prompt
        full_prompt = f"{QA_PAIRS_SYSTEM_PROMPT}\n\n{QA_PAIRS_HUMAN_PROMPT.format(text=text)}"

        try:
            # 调用 deepseek-v4-pro
            response = client.chat.completions.create(
                model="deepseek-v4-pro",
                messages=[
                    {"role": "user", "content": full_prompt}
                ],
                temperature=0.3,
                stream=False
            )

            result = response.choices[0].message.content.strip()
            print("API返回内容：", result[:200])

            # 解析JSON
            qas = json.loads(result)
            if not isinstance(qas, list):
                continue

            # 格式转换（和你原有结构一致）
            for qa in qas:
                if "question" in qa and "answer" in qa:
                    all_data.append({
                        "instruction": "你是一个运动健康垂直领域的专家，请根据专业知识回答用户问题",
                        "input": qa["question"],
                        "output": qa["answer"],
                        "metadata": {"source": SOURCE_NAME}
                    })

        except Exception as e:
            print(f"当前文本调用失败：{str(e)[:150]}")
            continue

    # 3. 写入最终JSON文件
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(all_data, f, ensure_ascii=False, indent=2)

    print(f"\n✅ 生成完成！共 {len(all_data)} 条数据 → {OUTPUT_FILE}")

if __name__ == "__main__":
    main()