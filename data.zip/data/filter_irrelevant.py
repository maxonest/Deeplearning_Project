import json

# ===================== 配置区 =====================

INPUT_FILE = "dataset.json"

OUTPUT_FILE = "dataset_clean.json"

# 保存被删除的数据，方便检查
REMOVED_FILE = "removed_samples.json"

# ===================== 黑名单 =====================

BAD_KEYWORDS = [

    # 社交媒体运营
    "点赞",
    "点赞量",
    "阅读量",
    "收藏量",
    "粉丝",
    "涨粉",
    "引流",
    "账号运营",
    "运营技巧",
    "爆款笔记",
    "爆文",
    "公众号运营",

    # 平台认证
    "知乎认证",
    "个人认证",
    "蓝V认证",
    "黄V认证",
    "认证账号",

    # 爬虫采集
    "八爪鱼采集器",
    "爬虫软件",
    "数据采集",
    "采集规则",
    "导出数据",
    "去除重复项",

    # 电商营销
    "淘宝店铺",
    "电商运营",
    "直播带货",
    "推广链接",

    # 旅游
    "旅游攻略",
    "景点推荐",
    "酒店推荐",
    "携程",
    "民宿",
    "自由行",

    # 园林景观
    "园林设计",
    "景观设计",
    "花境",
    "植物配置",
    "景观工程",

    # 护肤美容（非运动健康）
    "淡斑",
    "祛斑",
    "刷酸",
    "黑头",
    "毛孔粗大",
    "护肤品",
    "精华液",
    "面膜",
    "防晒霜",

    # 医美
    "水光针",
    "热玛吉",
    "超声炮",

    # 无训练价值内容
    "作者认为",
    "本文介绍",
    "本篇文章",
]

# ===================== 白名单 =====================

HEALTH_KEYWORDS = [

    # 运动训练
    "运动",
    "健身",
    "训练",
    "力量训练",
    "有氧",
    "无氧",
    "跑步",
    "骑行",
    "游泳",

    # 动作
    "深蹲",
    "卧推",
    "硬拉",
    "引体向上",
    "俯卧撑",
    "卷腹",
    "平板支撑",

    # 身体部位
    "肌肉",
    "骨骼",
    "关节",
    "肩胛",
    "膝盖",
    "腰椎",
    "脊柱",

    # 康复
    "康复",
    "疼痛",
    "损伤",
    "扭伤",
    "拉伤",

    # 营养
    "蛋白质",
    "碳水",
    "脂肪",
    "肌酸",
    "维生素",
    "补剂",

    # 身体指标
    "体脂",
    "BMI",
    "心率",
    "血压",

    # 健康管理
    "减脂",
    "减肥",
    "增肌",
    "塑形",
    "抗衰",
    "衰老",
    "睡眠",

    # 慢病
    "糖尿病",
    "高血压",
    "骨质疏松",

    # ACSM常见内容
    "VO₂",
    "VO2",
    "最大摄氧量",
    "体能测试",
    "运动处方",

    # 常见健康主题
    "健康",
    "体重",
    "代谢",
    "恢复",
]

# ==================================================


def contains_keyword(text, keyword_list):
    return any(keyword in text for keyword in keyword_list)


def main():

    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)

    filtered_data = []
    removed_data = []

    removed_count = 0

    for item in data:

        question = item.get("input", "")
        answer = item.get("output", "")

        text = question + answer

        # 命中黑名单
        hit_bad = contains_keyword(text, BAD_KEYWORDS)

        # 命中白名单
        hit_health = contains_keyword(text, HEALTH_KEYWORDS)

        # 规则：
        # 黑名单命中且白名单未命中 → 删除
        if hit_bad and not hit_health:
            removed_count += 1
            removed_data.append(item)
            continue

        filtered_data.append(item)

    # 保存过滤后的数据
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(
            filtered_data,
            f,
            ensure_ascii=False,
            indent=2
        )

    # 保存被删除的数据
    with open(REMOVED_FILE, "w", encoding="utf-8") as f:
        json.dump(
            removed_data,
            f,
            ensure_ascii=False,
            indent=2
        )

    print("=" * 60)
    print("过滤完成")
    print("=" * 60)

    print(f"原始数据量      : {len(data)}")
    print(f"删除数据量      : {removed_count}")
    print(f"保留数据量      : {len(filtered_data)}")

    print()
    print(f"过滤后文件      : {OUTPUT_FILE}")
    print(f"删除样本文件    : {REMOVED_FILE}")

    print("=" * 60)


if __name__ == "__main__":
    main()