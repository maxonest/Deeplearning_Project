import json
from pathlib import Path

# ===================== 配置区 =====================

INPUT_FILES = [
    "dataset_ACSM.json",
    "dataset_xhs.json",
    "dataset_gzh.json",
    "dataset_zh.json"
]

OUTPUT_FILE = "dataset.json"

MIN_QUESTION_LEN = 5
MIN_ANSWER_LEN = 15

# =================================================


def normalize_text(text):
    """
    文本标准化
    """
    if not text:
        return ""

    text = str(text).strip()

    # 连续空格压缩
    text = " ".join(text.split())

    return text


def load_json(file_path):
    """
    读取json文件
    """
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def main():

    merged_data = []

    original_count = 0

    print("=" * 60)
    print("开始读取文件...")
    print("=" * 60)

    # 读取所有数据
    for file in INPUT_FILES:

        if not Path(file).exists():
            print(f"文件不存在：{file}")
            continue

        data = load_json(file)

        print(f"{file}: {len(data)} 条")

        original_count += len(data)

        merged_data.extend(data)

    print("\n")
    print("=" * 60)
    print(f"合并后总数据量：{len(merged_data)}")
    print("=" * 60)

    # ==========================
    # 清洗
    # ==========================

    seen_questions = set()

    cleaned_data = []

    empty_count = 0
    short_count = 0
    duplicate_count = 0

    for item in merged_data:

        instruction = normalize_text(item.get("instruction", ""))
        question = normalize_text(item.get("input", ""))
        answer = normalize_text(item.get("output", ""))

        # 空字段
        if not question or not answer:
            empty_count += 1
            continue

        # 过短问题
        if len(question) < MIN_QUESTION_LEN:
            short_count += 1
            continue

        # 过短答案
        if len(answer) < MIN_ANSWER_LEN:
            short_count += 1
            continue

        # 问题去重
        question_key = question.lower()

        if question_key in seen_questions:
            duplicate_count += 1
            continue

        seen_questions.add(question_key)

        cleaned_data.append(item)

    # ==========================
    # 保存
    # ==========================

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(
            cleaned_data,
            f,
            ensure_ascii=False,
            indent=2
        )

    print("\n")
    print("=" * 60)
    print("清洗完成")
    print("=" * 60)

    print(f"原始总数据量      : {original_count}")
    print(f"合并后数据量      : {len(merged_data)}")
    print(f"空字段删除        : {empty_count}")
    print(f"过短样本删除      : {short_count}")
    print(f"重复问题删除      : {duplicate_count}")
    print(f"最终保留数据量    : {len(cleaned_data)}")

    print("\n")
    print(f"最终文件已保存：{OUTPUT_FILE}")


if __name__ == "__main__":
    main()
