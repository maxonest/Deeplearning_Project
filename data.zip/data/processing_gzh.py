import pandas as pd
import re

# ===================== 配置区 =====================
CSV_FILE = "/Users/wangluqi/Desktop/神经网络与深度学习/期末/搜狗.csv"  # 你的公众号CSV文件名
OUTPUT_TXT = "公众号文本.txt"  # 输出的干净文本文件名
MIN_CONTENT_LENGTH = 100  # 过滤正文少于100字的无效文章
# ==================================================

# 1. 读取CSV文件
print("正在读取CSV文件...")
df = pd.read_csv(CSV_FILE, header=0)  # header=0 表示第一行是列名

# 2. 提取核心列：标题（第2列，索引1）、正文（第9列，索引8）
# 自动适配列名，避免列名乱码问题
title_col = df.columns[1]
content_col = df.columns[8]
print(f"提取标题列：{title_col}，正文列：{content_col}")


# 3. 文本清洗函数
def clean_text(text):
    if pd.isna(text):
        return ""
    # 去除多余换行、连续空行
    text = re.sub(r'\n+', '\n', str(text))
    # 去除多余空格、制表符
    text = re.sub(r'\s+', ' ', text)
    # 去除首尾空白
    return text.strip()


# 4. 遍历每篇文章，清洗并合并
clean_articles = []
for idx, row in df.iterrows():
    title = clean_text(row[title_col])
    content = clean_text(row[content_col])

    # 过滤无效文章：标题为空/正文过短
    if not title or len(content) < MIN_CONTENT_LENGTH:
        continue

    # 合并成单篇文章格式：## 标题 + 正文，和你之前的文本格式完全统一
    article = f"## {title}\n{content}\n\n"
    clean_articles.append(article)

# 5. 保存最终干净文本
with open(OUTPUT_TXT, "w", encoding="utf-8") as f:
    f.writelines(clean_articles)

print(f"✅ 处理完成！共清洗有效文章 {len(clean_articles)} 篇")
print(f"干净文本已保存至：{OUTPUT_TXT}")