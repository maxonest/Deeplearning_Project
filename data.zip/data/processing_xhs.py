import pandas as pd
import re

# 1. 读取Excel文件
df = pd.read_excel('/Users/wangluqi/Desktop/神经网络与深度学习/期末/小红书1.xlsx', sheet_name='Sheet1')
print(f"原始数据总行数: {len(df)}")

# ==================== 定义过滤规则 ====================

# 需要过滤的标题/正文关键词（内容包含这些的整行删除）
FILTER_KEYWORDS = [
    # 互动/抽奖类
    '抽奖', '宠粉', '福利', '送书', '礼物', '红包', '奖品',
    '投票', '问卷', '调查', '扫码', '进群', '加群', '粉丝群',
    # 节日/祝福类
    '母亲节', '父亲节', '圣诞', '元旦', '春节', '中秋', '端午',
    '祝福', '节日快乐', '生日快乐', '新年快乐',
    # 运营类内容
    '粉丝', '关注', '点赞', '收藏', '破万', '破千',
    '阅读量', '浏览量', '赞藏', '互动', '评论', '转发',"开号",
"优质内容","日更","账号","公众号","运营技巧",
    # 个人生活/无关内容
    '女儿', '儿子', '老公', '老婆', '父母', '家人', '朋友',
    '鲜花', '礼物', '咖啡', '茶具', '家居',
    # 打卡/日常
    '打卡', '探店', '旅游', '旅行', '风景', '拍照',
    # 低质量内容
    '招募', '征稿', '合作', '推广', '广告',
# 纯个人经历
"感谢大家关注","感谢支持","成长清单","获得大家认可","最大的收获","最大的成就感","成长的喜悦",
# 人生感悟
    "生活即修行", "内心深处", "人生哲理", "心灵足迹", "自然美", "温柔", "宁静", "花开花落", "沧海桑田",
# 风景旅游
"江南","山塘","山塘街","瀑布","站台","茶人心语","茶香","茶山"
]

# 优质内容关键词（优先保留，即使长度较短）
PRIORITY_KEYWORDS = [
    '高度近视', '网脱', '视网膜', '眼底',
    '健身', '运动', '健康', '力量训练', '有氧', '无氧', '深蹲', '硬拉', '卧推',
    '抗炎', '炎症', '抗氧化', '自由基',
    '胶原蛋白', '弹性蛋白', '皮肤', '护肤', '防晒',
    '睡眠', '失眠', '熬夜', '作息',
    '养生', '中医', '气血', '脾', '肝', '肾',
    '饮食', '食谱', '蛋白质', '碳水', '脂肪',
    '代谢', '线粒体', '细胞', '端粒',
    '激素', '皮质醇', '雌激素', '雄激素',
    '维生素', '矿物质', '微量元素'
]

# 低质短文本阈值（小于此长度且不含优先关键词的删除）
MIN_TEXT_LENGTH = 15


# 纯表情/符号判断（匹配太多emoji或符号的行）
def is_mostly_emoji(text):
    if not text or len(text) < 10:
        return False
    emoji_pattern = re.compile(r'[\U00010000-\U0010ffff\u2600-\u26FF\u2700-\u27BF\u1F300-\u1F6FF\u1F900-\u1F9FF]+')
    emoji_count = len(emoji_pattern.findall(text))
    # 如果emoji超过总字符的30%，认为是纯表情内容
    return emoji_count > len(text) * 0.3


def clean_text(text):
    """清理单条文本"""
    if pd.isna(text):
        return ''

    text = str(text)

    # 去掉#话题标签
    text = re.sub(r'#\w+', '', text)
    # 去掉@用户
    text = re.sub(r'@\w+', '', text)
    # 去掉网页链接
    text = re.sub(r'https?://\S+', '', text)
    # 去掉 [任意内容] 格式
    text = re.sub(r'\[.*?\]', '', text)
    # 去掉 我在.*?的笔记
    text = re.sub(r'我在.*?的笔记', '', text)
    # 去掉中文小括号内容（博主签名等）
    text = re.sub(r'（.*?）', '', text)
    text = re.sub(r'\(.*?\)', '', text)

    # 去掉多余换行和空格
    text = re.sub(r'\n+', '\n', text)
    text = re.sub(r'\s+', ' ', text)

    return text.strip()


def should_keep_row(title, content):
    """判断是否保留该行"""
    # 空内容过滤
    if not content or len(content) < 5:
        return False

    # 纯表情过滤
    if is_mostly_emoji(content):
        return False

    # 优先关键词检查（如果包含优先关键词，直接保留）
    for kw in PRIORITY_KEYWORDS:
        if kw in title or kw in content:
            return True

    # 过滤关键词检查（包含则删除）
    combined = f"{title} {content}"
    for kw in FILTER_KEYWORDS:
        if kw in combined:
            return False

    # 长度检查（不含优先关键词的短内容删除）
    if len(content) < MIN_TEXT_LENGTH:
        return False

    return True


def is_substantive_content(content):
    """判断内容是否有实质信息（不是纯列表或标题）"""
    # 如果只是纯分割线或短标题
    if content.count('\n') < 1 and len(content) < 100:
        # 检查是否只是列举了几个词
        words = re.findall(r'[\u4e00-\u9fa5]+', content)
        if len(words) < 5:
            return False

    # 检查是否只是纯格式（全是|分隔符等）
    pipe_ratio = content.count('|') / max(len(content), 1)
    if pipe_ratio > 0.3:
        return False

    return True


# ==================== 主处理流程 ====================

# 清洗标题和正文
df['清洗后标题'] = df['标题'].apply(clean_text)
df['清洗后正文'] = df['正文内容'].apply(clean_text)

# 过滤无效行
valid_rows = []
for idx, row in df.iterrows():
    title = row['清洗后标题']
    content = row['清洗后正文']

    if should_keep_row(title, content) and is_substantive_content(content):
        valid_rows.append(row)

df_valid = pd.DataFrame(valid_rows).reset_index(drop=True)

# 去重
df_valid = df_valid.drop_duplicates(subset=['清洗后正文']).reset_index(drop=True)

print(f"清洗后有效数据行数: {len(df_valid)}")
print(f"过滤掉的无效数据行数: {len(df) - len(df_valid)}")

# 输出预览
print("\n=== 预览前5条有效内容 ===")
for i in range(min(5, len(df_valid))):
    print(f"\n--- {i + 1} ---")
    print(f"标题: {df_valid.iloc[i]['清洗后标题'][:50]}")
    print(f"正文: {df_valid.iloc[i]['清洗后正文'][:100]}...")

# 保存清洗后的Excel
save_excel_path = '/Users/wangluqi/Desktop/神经网络与深度学习/期末/小红书运动健康内容_清洗后.xlsx'
df_valid.to_excel(save_excel_path, index=False)
print(f"\n清洗后的有效内容已保存到 {save_excel_path}")

# 生成结构化Markdown文本
output_text = "# 小红书文本\n\n"
for idx, row in df_valid.iterrows():
    title = row['清洗后标题']
    content = row['清洗后正文']
    # 标题为空时用默认标题
    if not title or len(title) < 2:
        title = f"健康科普_{idx + 1}"
    output_text += f"## {title}\n{content}\n\n"

# 保存为TXT文件
save_path = "/Users/wangluqi/Desktop/神经网络与深度学习/Deeplearning_Project-main/data/小红书文本.txt"
with open(save_path, 'w', encoding='utf-8') as f:
    f.write(output_text)

print(f"结构化Markdown文本已保存")
