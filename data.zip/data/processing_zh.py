import pandas as pd
import re

# ===================== 配置区 =====================
EXCEL_FILE = "/Users/wangluqi/Desktop/神经网络与深度学习/期末/知乎-1.xlsx"
OUTPUT_TXT = "知乎文本.txt"

MIN_ANSWER_LENGTH = 30
# ==================================================

print("正在读取知乎数据...")

df = pd.read_excel(EXCEL_FILE)

print(f"原始数据：{len(df)} 条")

# 获取列名
question_col = "问题标题"
answer_col = "回答内容"
likes_col = "赞同数"


def clean_text(text):
    """
    清洗知乎文本
    """

    if pd.isna(text):
        return ""

    text = str(text)

    # 删除HTML图片
    text = re.sub(r"<img.*?>", "", text)

    # 删除HTML标签
    text = re.sub(r"<.*?>", "", text)

    # 删除URL
    text = re.sub(r"http[s]?://\S+", "", text)

    # 删除多余换行
    text = re.sub(r"\n+", "\n", text)

    # 删除连续空格
    text = re.sub(r"\s+", " ", text)

    text = re.sub(r"^谢邀[，,。.\s]*", "", text)
    text = re.sub(r"^利益相关[：:\s]*", "", text)
    text = re.sub(r"^先说结论[：:\s]*", "", text)

    return text.strip()


clean_articles = []

for _, row in df.iterrows():

    question = clean_text(row[question_col])
    answer = clean_text(row[answer_col])

    likes = row[likes_col]

    # 空值处理
    if pd.isna(likes):
        likes = 0

    # 过滤短回答
    if len(answer) < MIN_ANSWER_LENGTH:
        continue

    article = (
        f"## 问题：{question}\n\n"
        f"回答：\n{answer}\n\n"
        f"{'-'*50}\n\n"
    )

    clean_articles.append(article)

with open(OUTPUT_TXT, "w", encoding="utf-8") as f:
    f.writelines(clean_articles)

print(f"✅ 保留高质量回答：{len(clean_articles)} 条")
print(f"输出文件：{OUTPUT_TXT}")
