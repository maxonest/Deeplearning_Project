import json
import random

with open("dataset_clean.json", "r", encoding="utf-8") as f:
    data = json.load(f)

samples = random.sample(data, 100)

for i, item in enumerate(samples):
    print("=" * 50)
    print(item["input"])
    print(item["output"])